// Shared helpers: Supabase REST cache (service role, server-side only) + soft rate limit.
const SB = process.env.SUPABASE_URL, KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const hdr = () => ({ apikey: KEY, Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json' });

async function cacheGet(key) {
  if (!SB || !KEY) return null;
  try {
    const r = await fetch(`${SB}/rest/v1/spherex_cache?key=eq.${encodeURIComponent(key)}&select=payload,fetched_at,expires_at`, { headers: hdr() });
    const [row] = await r.json();
    return row && new Date(row.expires_at) > new Date() ? row : null;
  } catch { return null; }
}
async function cacheSet(key, payload, ttlSec) {
  if (!SB || !KEY) return;
  try {
    await fetch(`${SB}/rest/v1/spherex_cache`, {
      method: 'POST',
      headers: { ...hdr(), Prefer: 'resolution=merge-duplicates' },
      body: JSON.stringify({ key, payload, fetched_at: new Date().toISOString(), expires_at: new Date(Date.now() + ttlSec * 1000).toISOString() })
    });
  } catch {}
}
// Best-effort per-instance limiter (CDN caching via s-maxage does the heavy lifting).
const hits = new Map();
function limited(ip, max = 30, windowMs = 60000) {
  const now = Date.now(), h = (hits.get(ip) || []).filter(t => now - t < windowMs);
  h.push(now); hits.set(ip, h);
  return h.length > max;
}
module.exports = { cacheGet, cacheSet, limited, configured: !!(SB && KEY) };
