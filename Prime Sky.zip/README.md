# PRIME SKY — deployment

## 1. Three edits to YOUR original index.html (everything else stays untouched)
1. Before `</head>` add: `<link rel="stylesheet" href="explorer.css">`
2. Before `</body>` add: `<script src="explorer.js" defer></script>`
3. In `CosmosEngine.animate()`, directly after `requestAnimationFrame(this.animate);` add:
   `if (window.__psPaused) return;`   (stops WebGL work while the explorer is open)

Also set the Explore link to `href="#sky"`. Put `three.min.js` beside index.html as before.
(explorer.css sets `user-select:text` inside the explorer, since your body disables selection.)

## 2. Supabase
Run `supabase/migrations/001_cache.sql` in the SQL editor. RLS is on with no public policies, so only the server (service-role key) can touch it. Supabase is optional: without env vars the API still works, just uncached.

## 3. Vercel
`vercel link` → add env vars from `.env.example` (Project → Settings → Environment Variables) → `vercel --prod`.
No build step needed; static files + `/api/*.js` functions.

## API
`GET /api/spherex-search?ra=<0-360>&dec=<-90..90>&radius=<deg ≤0.5>[&collection=spherex_qr2|spherex_qr|spherex_qr_deep]`
Queries IRSA SIA2 (`https://irsa.ipac.caltech.edu/SIA`, `RESPONSEFORMAT=CSV`), returns `{source, count, rows[{obs_id, mjd_start, date_utc, wavelength_um, access_url}], cache}`. 6 h cache in Supabase + CDN, 30 req/min soft limit, 22 s timeout, 502/504 on upstream failure. Missing fields are `null` (UI shows "unavailable").

## Not verified / not built yet
- Collection names come from IRSA docs; QR2 is the default. Confirm `spherex_qr2` returns rows for your fields before the demo.
- Column names (`t_min`, `em_min`, `em_max`, `obs_id`, `access_url`) are standard ObsCore names; `columnsReturned` in the response shows what IRSA actually sent.
- Phase 4 images (side-by-side, blink, difference) need FITS cutout rendering; not implemented.
- Not tested live: this environment couldn't deploy or reach IRSA.
