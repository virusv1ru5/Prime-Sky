/* PRIME SKY explorer — injects its own UI; leaves the landing page code untouched. */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const NAV = [['home', 'Home'], ['sky', 'Sky Explorer'], ['data', 'SPHEREx Data'], ['compare', 'Epoch Comparison'], ['about', 'About the Mission']];
  const SURVEYS = [['P/DSS2/color', 'Optical (DSS2)'], ['P/2MASS/color', 'Near-IR (2MASS)'], ['P/allWISE/color', 'Mid-IR (AllWISE)']];
  const REGIONS = [['M 42', 'Orion Nebula'], ['M 31', 'Andromeda'], ['Sgr A*', 'Galactic Centre'], ['LMC', 'Large Magellanic Cloud']];
  const BANDS = [['D1', .75, 1.09], ['D2', 1.10, 1.62], ['D3', 1.63, 2.41], ['D4', 2.42, 3.82], ['D5', 3.83, 4.41], ['D6', 4.42, 5.00]];
  let aladin = null, view = 'home', pos = { ra: 83.8221, dec: -5.3911, name: 'M 42' }, results = null;

  const app = document.createElement('div');
  app.id = 'ps-app';
  app.innerHTML = `
  <nav id="ps-nav" aria-label="Main"><span class="brand"><b>✦</b> PRIME SKY</span>${NAV.map(([k, l]) => `<button data-v="${k}">${l}</button>`).join('')}</nav>
  <div id="ps-main">
    <section class="ps-view" id="v-sky">
      <div id="aladin" role="application" aria-label="Interactive sky map"></div>
      <div class="ps-panel" id="ps-tools">
        <form id="ps-search" style="display:flex;gap:6px"><input id="ps-q" placeholder="Search object (M31, Vega…)" aria-label="Search object"><button class="ps-btn">Go</button></form>
        <select id="ps-survey" aria-label="Sky survey">${SURVEYS.map(([i, l]) => `<option value="${i}">${l}</option>`).join('')}</select>
        <select id="ps-region" aria-label="Region"><option value="">Regions…</option>${REGIONS.map(([i, l]) => `<option value="${i}">${l}</option>`).join('')}</select>
      </div>
      <div class="ps-panel" id="ps-coords">RA — · Dec —</div>
      <div class="ps-panel" id="ps-info"><span class="ps-dim">Click the sky or search to select a position.</span></div>
    </section>
    <section class="ps-view" id="v-data"><div class="ps-card" id="data-body"></div></section>
    <section class="ps-view" id="v-compare"><div class="ps-card" id="cmp-body"></div></section>
    <section class="ps-view" id="v-about"><div class="ps-card">
      <h2>About the Mission</h2>
      <p>SPHEREx is a NASA all-sky infrared spectral survey mission. Its detectors cover six bands (≈0.75–5.0 µm):</p>
      <table class="ps-tbl"><tr><th>Band</th><th>Wavelength (µm)</th></tr>${BANDS.map(b => `<tr><td>${b[0]}</td><td>${b[1]}–${b[2]}</td></tr>`).join('')}</table>
      <p style="margin-top:12px">Data: <a href="https://irsa.ipac.caltech.edu/data/SPHEREx/" target="_blank" rel="noopener">NASA/IPAC IRSA</a> (SIA2 API). Sky imagery: CDS Aladin Lite &amp; HiPS surveys. Band ranges from the SPHEREx query tooling documentation.</p>
    </div></section>
  </div>`;
  document.body.appendChild(app);

  function setView(v, push = true) {
    if (!NAV.some(n => n[0] === v)) v = 'home';
    view = v;
    if (push && location.hash !== '#' + v) history.replaceState(null, '', v === 'home' ? '#' : '#' + v);
    const home = v === 'home';
    window.__psPaused = !home;                       // pause Three.js render loop (needs 1-line patch)
    document.getElementById('ui').style.opacity = home ? '' : '0';
    document.getElementById('ui').style.visibility = home ? '' : 'hidden';
    if (home) { app.classList.remove('vis'); setTimeout(() => app.classList.remove('on'), 800); return; }
    app.classList.add('on'); requestAnimationFrame(() => app.classList.add('vis'));
    document.querySelectorAll('#ps-nav button').forEach(b => b.classList.toggle('act', b.dataset.v === v));
    document.querySelectorAll('.ps-view').forEach(s => s.classList.toggle('act', s.id === 'v-' + (v === 'about' ? 'about' : v)));
    if (v === 'sky') initSky();
    if (v === 'data') renderData();
    if (v === 'compare') renderCompare();
  }

  function loadAladin() {
    return window.A ? Promise.resolve() : new Promise((ok, no) => {
      const s = document.createElement('script');
      s.src = 'https://aladin.cds.unistra.fr/AladinLite/api/v3/latest/aladin.js';
      s.onload = ok; s.onerror = () => no(new Error('Could not load Aladin Lite')); document.head.appendChild(s);
    });
  }
  async function initSky() {
    if (aladin) return;
    const info = $('#ps-info');
    try {
      await loadAladin(); await A.init;
      aladin = A.aladin('#aladin', { survey: 'P/DSS2/color', target: pos.name, fov: 2, cooFrame: 'ICRSd', showCooGrid: false, showFullscreenControl: false });
      aladin.on('mouseMove', e => { if (e && e.ra != null) $('#ps-coords').textContent = `RA ${e.ra.toFixed(4)}° · Dec ${e.dec.toFixed(4)}° (ICRS)`; });
      aladin.on('click', e => { if (e && e.ra != null && !e.isDragging) select(e.ra, e.dec, null); });
      select(pos.ra, pos.dec, pos.name);
    } catch (err) { info.innerHTML = `<span class="ps-err">Sky map failed to load: ${esc(err.message)}. Check your connection and reload.</span>`; }
  }
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function select(ra, dec, name) {
    pos = { ra, dec, name: name || `Position ${ra.toFixed(3)}, ${dec.toFixed(3)}` }; results = null;
    $('#ps-info').innerHTML = `<b>${esc(pos.name)}</b><div class="ps-mono">RA ${ra.toFixed(5)}°<br>Dec ${dec.toFixed(5)}° (ICRS)</div>
      <div class="ps-dim" style="margin:6px 0">Object type, magnitude and distance: not provided by this map layer.</div>
      <button class="ps-btn" id="ps-go">Find SPHEREx observations here</button>
      ${name ? ` <a class="ps-btn" target="_blank" rel="noopener" href="https://simbad.cds.unistra.fr/simbad/sim-basic?Ident=${encodeURIComponent(name)}">SIMBAD</a>` : ''}`;
    $('#ps-go').onclick = () => setView('data');
  }
  $('#ps-search').onsubmit = e => {
    e.preventDefault(); const q = $('#ps-q').value.trim(); if (!q || !aladin) return;
    $('#ps-info').innerHTML = 'Resolving…';
    aladin.gotoObject(q, {
      success: r => { const c = aladin.getRaDec(); select(c[0], c[1], q); },
      error: () => { $('#ps-info').innerHTML = `<span class="ps-err">“${esc(q)}” could not be resolved by CDS Sesame.</span>`; }
    });
  };
  $('#ps-survey').onchange = e => aladin && aladin.setImageSurvey(e.target.value);
  $('#ps-region').onchange = e => { if (e.target.value && aladin) { aladin.gotoObject(e.target.value, { success: () => { const c = aladin.getRaDec(); select(c[0], c[1], e.target.value); } }); } };

  async function fetchObs() {
    if (results && results.q === `${pos.ra},${pos.dec}`) return results;
    const r = await fetch(`/api/spherex-search?ra=${pos.ra.toFixed(5)}&dec=${pos.dec.toFixed(5)}&radius=0.05`);
    const j = await r.json(); if (!r.ok) throw new Error(j.detail || j.error || r.status);
    return (results = Object.assign(j, { q: `${pos.ra},${pos.dec}` }));
  }
  const fmtBand = w => w ? `${w[0].toFixed(2)}–${w[1].toFixed(2)} µm` : 'unavailable';
  async function renderData() {
    const el = $('#data-body');
    el.innerHTML = `<h2>SPHEREx Data</h2><p class="ps-mono">${esc(pos.name)} · RA ${pos.ra.toFixed(4)}° Dec ${pos.dec.toFixed(4)}°</p><p>Querying NASA/IPAC IRSA…</p>`;
    try {
      const d = await fetchObs();
      el.innerHTML = `<h2>SPHEREx Data</h2><p class="ps-mono">${esc(pos.name)} · RA ${pos.ra.toFixed(4)}° Dec ${pos.dec.toFixed(4)}°</p>
      <p class="ps-dim">Source: ${esc(d.source.service)} · collection <b>${esc(d.source.collection)}</b> · ${d.source.query.radius_deg}° cone · ${d.cache.hit ? 'served from cache' : 'live query'}</p>
      <p>${d.count} spectral image${d.count === 1 ? '' : 's'} overlap this position.</p>
      ${d.count ? `<div style="overflow:auto"><table class="ps-tbl"><tr><th>Observation (UTC)</th><th>Band range</th><th>Observation ID</th><th>Product</th></tr>
      ${d.rows.map(r => `<tr><td>${r.date_utc ? r.date_utc.replace('T', ' ').slice(0, 16) : 'unavailable'}</td><td>${fmtBand(r.wavelength_um)}</td><td class="ps-mono">${esc(r.obs_id ?? 'unavailable')}</td><td>${r.access_url ? `<a href="${esc(r.access_url)}" target="_blank" rel="noopener">link</a>` : 'unavailable'}</td></tr>`).join('')}</table></div>` : ''}
      <p class="ps-dim">Per-object magnitudes, distances and spectra are not shown: this view lists archive image products only.</p>`;
    } catch (err) { el.innerHTML += `<p class="ps-err">Could not reach the SPHEREx archive: ${esc(err.message)}. Try again shortly.</p>`; }
  }

  async function renderCompare() {
    const el = $('#cmp-body');
    el.innerHTML = `<h2>Epoch Comparison</h2><p>Loading observation dates for ${esc(pos.name)}…</p>`;
    try {
      const d = await fetchObs();
      const days = [...new Set(d.rows.filter(r => r.date_utc).map(r => r.date_utc.slice(0, 10)))];
      if (days.length < 2) { el.innerHTML = `<h2>Epoch Comparison</h2><p>Only ${days.length} observation date${days.length === 1 ? '' : 's'} found for this position in <b>${esc(d.source.collection)}</b>. At least two are needed to compare.</p>`; return; }
      el.innerHTML = `<h2>Epoch Comparison</h2><p class="ps-dim">${esc(pos.name)} · dates are real archive observation times.</p>
      <label>Epoch A <select id="ea"></select></label> <label>Epoch B <select id="eb"></select></label>
      <input type="range" id="ts" min="0" max="${days.length - 1}" value="0" aria-label="Timeline">
      <div id="cmp-out" style="margin-top:12px"></div>
      <p class="ps-dim">Image side-by-side, blink and difference views are not implemented yet (Phase 4): they require rendering FITS cutouts, which is next.</p>`;
      const opts = days.map((x, i) => `<option value="${i}">${x}</option>`).join('');
      $('#ea').innerHTML = opts; $('#eb').innerHTML = opts; $('#eb').value = days.length - 1;
      const show = () => {
        const list = i => d.rows.filter(r => r.date_utc && r.date_utc.slice(0, 10) === days[i]);
        const col = i => `<div><b>${days[i]}</b><br>${list(i).map(r => `<span class="ps-mono">${fmtBand(r.wavelength_um)}</span>${r.access_url ? ` · <a href="${esc(r.access_url)}" target="_blank" rel="noopener">product</a>` : ''}`).join('<br>')}</div>`;
        $('#cmp-out').innerHTML = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">${col(+$('#ea').value)}${col(+$('#eb').value)}</div>`;
      };
      $('#ea').onchange = $('#eb').onchange = show;
      $('#ts').oninput = e => { $('#ea').value = e.target.value; show(); };
      show();
    } catch (err) { el.innerHTML = `<h2>Epoch Comparison</h2><p class="ps-err">Could not load epochs: ${esc(err.message)}</p>`; }
  }

  app.addEventListener('click', e => { const b = e.target.closest('#ps-nav button'); if (b) setView(b.dataset.v); });
  const btn = document.getElementById('explore-btn');
  btn.addEventListener('click', e => { e.preventDefault(); setView('sky'); });
  window.addEventListener('hashchange', () => setView(location.hash.slice(1) || 'home', false));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && view !== 'home') setView('home'); });
  if (location.hash.length > 1) setTimeout(() => setView(location.hash.slice(1), false), 900);
})();
