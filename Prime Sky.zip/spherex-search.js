// GET /api/spherex-search?ra=83.82&dec=-5.39&radius=0.05[&collection=spherex_qr2]
// Proxies IRSA SIA2 (https://irsa.ipac.caltech.edu/SIA) and returns normalised ObsCore rows.
const { cacheGet, cacheSet, limited, configured } = require('./_lib');
const ALLOWED = ['spherex_qr', 'spherex_qr_deep', 'spherex_qr2']; // collections named in IRSA docs
const TTL = 6 * 3600;

function parseCSV(text) {
  const rows = []; let row = [], f = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(f); f = ''; }
    else if (c === '\n') { row.push(f); rows.push(row); row = []; f = ''; }
    else if (c !== '\r') f += c;
  }
  if (f || row.length) { row.push(f); rows.push(row); }
  return rows;
}
const num = v => (v === '' || v == null || isNaN(+v)) ? null : +v;

module.exports = async (req, res) => {
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0] || 'x';
  if (limited(ip)) return res.status(429).json({ error: 'Too many requests, slow down.' });
  const ra = num(req.query.ra), dec = num(req.query.dec);
  const radius = Math.min(num(req.query.radius) ?? 0.05, 0.5);
  const collection = req.query.collection || process.env.SPHEREX_COLLECTION || 'spherex_qr2';
  if (ra == null || dec == null || ra < 0 || ra > 360 || dec < -90 || dec > 90)
    return res.status(400).json({ error: 'ra (0-360) and dec (-90..90) in degrees (ICRS) are required.' });
  if (!ALLOWED.includes(collection)) return res.status(400).json({ error: 'Unknown collection', allowed: ALLOWED });

  const key = `sia2:${collection}:${ra.toFixed(3)}:${dec.toFixed(3)}:${radius.toFixed(3)}`;
  res.setHeader('Cache-Control', 's-maxage=3600, stale-while-revalidate=86400');
  const hit = await cacheGet(key);
  if (hit) return res.json({ ...hit.payload, cache: { hit: true, fetchedAt: hit.fetched_at } });

  const url = `https://irsa.ipac.caltech.edu/SIA?COLLECTION=${collection}&POS=circle+${ra}+${dec}+${radius}&RESPONSEFORMAT=CSV`;
  const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 22000);
  try {
    const r = await fetch(url, { signal: ctl.signal });
    if (!r.ok) throw new Error(`IRSA returned HTTP ${r.status}`);
    const table = parseCSV(await r.text());
    const cols = table[0] || [];
    const idx = n => cols.indexOf(n);
    const get = (row, n) => (idx(n) >= 0 ? row[idx(n)] : undefined);
    const rows = table.slice(1).filter(r => r.length === cols.length).slice(0, 500).map(row => {
      const tmin = num(get(row, 't_min')), emin = num(get(row, 'em_min')), emax = num(get(row, 'em_max'));
      return {
        obs_id: get(row, 'obs_id') ?? null,
        mjd_start: tmin,
        date_utc: tmin != null ? new Date((tmin - 40587) * 864e5).toISOString() : null, // MJD→UTC
        wavelength_um: emin != null && emax != null ? [emin * 1e6, emax * 1e6] : null,   // ObsCore em_* are metres
        access_url: get(row, 'access_url') ?? null,
        access_format: get(row, 'access_format') ?? null
      };
    }).sort((a, b) => (a.mjd_start ?? 0) - (b.mjd_start ?? 0));
    const payload = {
      source: { service: 'NASA/IPAC IRSA SIA2', url: 'https://irsa.ipac.caltech.edu/SIA', collection, query: { ra, dec, radius_deg: radius, frame: 'ICRS' } },
      columnsReturned: cols, count: rows.length, rows
    };
    await cacheSet(key, payload, TTL);
    res.json({ ...payload, cache: { hit: false, supabaseConfigured: configured } });
  } catch (e) {
    res.status(e.name === 'AbortError' ? 504 : 502).json({ error: 'SPHEREx archive unavailable', detail: String(e.message || e) });
  } finally { clearTimeout(to); }
};
