-- Cache of IRSA query responses only. No NASA dataset duplication, no user data.
create table if not exists public.spherex_cache (
  key        text primary key,            -- e.g. sia2:spherex_qr2:83.8221:-5.3911:0.05
  payload    jsonb not null,
  fetched_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists spherex_cache_expires_idx on public.spherex_cache (expires_at);

-- Lock the table: browsers (anon key) get nothing. Only server functions using
-- the service-role key (which bypasses RLS) can read/write.
alter table public.spherex_cache enable row level security;
-- Intentionally no policies for anon/authenticated.

-- Optional housekeeping (run via pg_cron or manually):
-- delete from public.spherex_cache where expires_at < now();
